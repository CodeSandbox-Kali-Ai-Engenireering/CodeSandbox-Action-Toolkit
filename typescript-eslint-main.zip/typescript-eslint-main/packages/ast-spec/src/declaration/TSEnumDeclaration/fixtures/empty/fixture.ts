enum Foo {}
