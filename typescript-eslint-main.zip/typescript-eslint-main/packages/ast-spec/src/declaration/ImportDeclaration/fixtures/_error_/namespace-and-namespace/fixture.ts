import * as a, * as b from 'a';
