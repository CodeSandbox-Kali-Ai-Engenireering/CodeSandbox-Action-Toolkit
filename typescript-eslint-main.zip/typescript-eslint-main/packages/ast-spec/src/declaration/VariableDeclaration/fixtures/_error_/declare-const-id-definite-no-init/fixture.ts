declare const foo!;
