var foo! = 1;
