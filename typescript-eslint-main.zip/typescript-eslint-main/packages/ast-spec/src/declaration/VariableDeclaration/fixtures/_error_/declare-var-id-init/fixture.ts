declare var foo = 1;
