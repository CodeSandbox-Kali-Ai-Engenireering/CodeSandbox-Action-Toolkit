function* foo(): any;
function* foo(): any {}
