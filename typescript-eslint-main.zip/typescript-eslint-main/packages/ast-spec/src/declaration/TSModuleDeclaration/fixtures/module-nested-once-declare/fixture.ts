declare module abc.def {}
