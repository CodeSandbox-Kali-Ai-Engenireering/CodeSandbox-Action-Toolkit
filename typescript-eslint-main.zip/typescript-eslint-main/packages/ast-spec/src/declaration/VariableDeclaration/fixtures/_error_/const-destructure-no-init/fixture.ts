const { foo };
