using { foo }: any = 1;
