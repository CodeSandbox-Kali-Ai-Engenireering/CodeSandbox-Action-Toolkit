class Foo {
  accessor ['prop'] = 'value';
}
