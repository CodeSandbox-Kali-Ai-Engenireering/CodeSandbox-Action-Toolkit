const foo! = 1;
