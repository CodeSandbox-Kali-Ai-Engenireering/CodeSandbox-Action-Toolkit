declare let foo!;
