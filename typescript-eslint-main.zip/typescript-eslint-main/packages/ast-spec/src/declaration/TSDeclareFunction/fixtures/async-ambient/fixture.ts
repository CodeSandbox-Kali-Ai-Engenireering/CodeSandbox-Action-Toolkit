declare module 'x' {
  async function foo(): any;
}
