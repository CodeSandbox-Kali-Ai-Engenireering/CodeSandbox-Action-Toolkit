export type A = 1;
