type T<U, V, W> = 1;
