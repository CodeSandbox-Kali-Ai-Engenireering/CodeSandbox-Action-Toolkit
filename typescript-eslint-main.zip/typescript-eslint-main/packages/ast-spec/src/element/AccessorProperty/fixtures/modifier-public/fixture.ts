class Foo {
  public accessor foo = 2;
}
