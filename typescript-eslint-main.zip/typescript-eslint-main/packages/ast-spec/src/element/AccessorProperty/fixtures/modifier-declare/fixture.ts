class Foo {
  declare accessor foo: number;
}
