abstract class Foo {
  abstract property = 1;
}
