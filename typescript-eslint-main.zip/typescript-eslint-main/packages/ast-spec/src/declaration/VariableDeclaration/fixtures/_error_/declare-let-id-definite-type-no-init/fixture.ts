declare let foo!: any;
