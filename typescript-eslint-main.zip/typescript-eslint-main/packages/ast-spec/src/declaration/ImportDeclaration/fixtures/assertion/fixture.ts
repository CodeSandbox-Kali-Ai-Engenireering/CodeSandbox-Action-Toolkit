import * as a from 'mod' assert { type: 'json' };
