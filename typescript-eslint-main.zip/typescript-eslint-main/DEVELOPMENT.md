# Development

See **https://typescript-eslint.io/contributing/local-development** for our development instructions.
Thanks! 💖
