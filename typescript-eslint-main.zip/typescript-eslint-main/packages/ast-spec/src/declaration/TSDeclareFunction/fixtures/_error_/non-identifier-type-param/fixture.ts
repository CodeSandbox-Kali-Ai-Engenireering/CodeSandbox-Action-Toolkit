declare function f<1>(): void;
