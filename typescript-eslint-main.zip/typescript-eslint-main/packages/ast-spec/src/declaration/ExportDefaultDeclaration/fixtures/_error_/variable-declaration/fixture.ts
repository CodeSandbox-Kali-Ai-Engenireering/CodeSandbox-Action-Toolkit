export default const x = 1;
