const foo!: any;
