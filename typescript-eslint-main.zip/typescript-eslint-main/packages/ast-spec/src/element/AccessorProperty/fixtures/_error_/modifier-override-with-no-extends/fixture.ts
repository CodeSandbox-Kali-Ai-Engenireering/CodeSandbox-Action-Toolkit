class Foo {
  override accessor foo = 2;
}
