class Foo {
  accessor prop: string = 'str';
}
