<App foo=<div /> />;
