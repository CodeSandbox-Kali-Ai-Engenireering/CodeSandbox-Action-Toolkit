class Foo {
  accessor prop: string;
}
