declare class Foo {}
