function foo<>() {}
