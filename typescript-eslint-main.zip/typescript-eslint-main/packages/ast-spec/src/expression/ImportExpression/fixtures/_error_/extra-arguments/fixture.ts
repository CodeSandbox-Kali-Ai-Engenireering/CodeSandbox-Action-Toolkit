import(
  "./source.json",
  {assert: {type: "json"}},
  extraArgument
);
