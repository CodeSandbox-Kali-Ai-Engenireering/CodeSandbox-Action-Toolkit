declare var foo;
