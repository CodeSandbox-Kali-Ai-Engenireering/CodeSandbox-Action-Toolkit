declare function foo(a);
