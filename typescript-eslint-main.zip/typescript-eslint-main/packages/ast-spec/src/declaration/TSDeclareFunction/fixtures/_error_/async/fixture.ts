declare async function foo();
