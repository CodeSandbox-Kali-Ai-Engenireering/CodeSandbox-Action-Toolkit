({ prop: 'string' }) satisfies { prop: string };
