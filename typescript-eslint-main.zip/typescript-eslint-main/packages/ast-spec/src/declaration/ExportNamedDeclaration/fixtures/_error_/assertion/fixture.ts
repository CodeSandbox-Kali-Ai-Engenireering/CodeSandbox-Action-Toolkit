export { foo } from 'mod' assert { type: 'json' };
