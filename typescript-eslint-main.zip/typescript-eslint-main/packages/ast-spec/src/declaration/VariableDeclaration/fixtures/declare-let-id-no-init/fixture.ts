declare let foo;
