declare var { foo }: any;
