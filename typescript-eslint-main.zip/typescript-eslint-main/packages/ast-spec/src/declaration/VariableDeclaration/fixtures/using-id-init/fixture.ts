using foo = 1;
