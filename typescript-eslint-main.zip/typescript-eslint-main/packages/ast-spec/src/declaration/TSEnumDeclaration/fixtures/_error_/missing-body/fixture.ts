enum Foo;
