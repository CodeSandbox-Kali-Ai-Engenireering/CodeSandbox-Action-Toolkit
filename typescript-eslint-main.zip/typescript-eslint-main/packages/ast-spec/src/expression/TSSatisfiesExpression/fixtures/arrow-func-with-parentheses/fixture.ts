(() => 1) satisfies () => number;
