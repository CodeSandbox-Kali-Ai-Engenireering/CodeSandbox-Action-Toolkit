class Foo {
  accessor prop = 'str';
}
