const { foo }: any;
