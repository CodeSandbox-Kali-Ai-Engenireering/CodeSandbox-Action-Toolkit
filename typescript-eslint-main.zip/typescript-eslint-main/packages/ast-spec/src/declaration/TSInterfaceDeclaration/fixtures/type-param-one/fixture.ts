interface F<T> {}
