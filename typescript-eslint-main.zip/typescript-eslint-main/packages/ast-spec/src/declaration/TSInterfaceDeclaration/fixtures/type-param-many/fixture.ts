interface F<T, U, V> {}
