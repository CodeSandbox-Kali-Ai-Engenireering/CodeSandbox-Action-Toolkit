foo === (1 satisfies number);
