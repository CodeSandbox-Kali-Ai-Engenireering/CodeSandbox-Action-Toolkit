class Foo implements Object {}
