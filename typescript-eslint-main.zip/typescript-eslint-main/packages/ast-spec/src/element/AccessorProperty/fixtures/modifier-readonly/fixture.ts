class Foo {
  readonly accessor foo = 2;
}
