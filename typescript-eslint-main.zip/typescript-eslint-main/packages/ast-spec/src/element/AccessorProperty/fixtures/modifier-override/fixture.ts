class Foo extends Bar {
  override accessor foo = 2;
}
