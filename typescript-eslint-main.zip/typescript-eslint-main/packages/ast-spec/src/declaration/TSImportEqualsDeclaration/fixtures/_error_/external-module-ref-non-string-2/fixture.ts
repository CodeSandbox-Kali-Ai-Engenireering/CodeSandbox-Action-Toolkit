import F = require(1 + 1);
