import * as b, a from 'mod';
