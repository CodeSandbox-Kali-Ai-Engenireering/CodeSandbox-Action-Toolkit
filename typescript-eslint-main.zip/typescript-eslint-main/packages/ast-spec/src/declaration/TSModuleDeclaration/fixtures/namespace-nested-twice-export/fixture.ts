export namespace abc.def.ghi {}
