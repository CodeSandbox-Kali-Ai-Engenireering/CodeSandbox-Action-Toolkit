declare var foo!;
