type T<U> = 1;
