declare function foo(a, b, c);
