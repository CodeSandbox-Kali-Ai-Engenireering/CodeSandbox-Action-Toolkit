(foo ? 1 : 0) satisfies number;
