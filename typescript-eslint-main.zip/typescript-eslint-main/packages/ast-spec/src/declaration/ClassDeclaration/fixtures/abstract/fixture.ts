abstract class Foo {}
