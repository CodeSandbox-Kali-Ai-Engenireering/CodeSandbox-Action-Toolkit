declare function foo<>(): void;
