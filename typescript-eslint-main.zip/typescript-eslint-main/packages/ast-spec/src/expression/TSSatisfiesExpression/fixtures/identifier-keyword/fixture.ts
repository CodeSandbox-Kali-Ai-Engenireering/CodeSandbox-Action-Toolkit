foo satisfies boolean;
