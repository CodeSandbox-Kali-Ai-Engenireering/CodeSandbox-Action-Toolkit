export * as 'foo' from 'module';
