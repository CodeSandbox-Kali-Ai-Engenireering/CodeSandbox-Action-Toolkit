declare module 'a';
