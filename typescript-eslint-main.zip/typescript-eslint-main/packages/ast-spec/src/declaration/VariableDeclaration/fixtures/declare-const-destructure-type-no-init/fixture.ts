declare const { foo }: any;
