class Foo extends Set<string> {}
