class Foo implements 'thing' {}
