declare const { foo };
