export type * from './BigIntLiteral/spec';
export type * from './BooleanLiteral/spec';
export type * from './NullLiteral/spec';
export type * from './NumberLiteral/spec';
export type * from './RegExpLiteral/spec';
export type * from './StringLiteral/spec';
