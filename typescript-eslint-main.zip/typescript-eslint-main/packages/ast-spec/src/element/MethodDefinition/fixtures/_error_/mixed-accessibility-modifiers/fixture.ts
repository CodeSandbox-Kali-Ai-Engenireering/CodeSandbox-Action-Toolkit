class Foo {
  public protected bar() {};
}
