class Foo {
  accessor [1] = 2;
}
