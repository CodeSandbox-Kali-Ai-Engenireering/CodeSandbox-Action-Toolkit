export * as mod from 'module';
