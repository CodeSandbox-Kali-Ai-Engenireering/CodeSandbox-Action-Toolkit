let { foo } = 1;
