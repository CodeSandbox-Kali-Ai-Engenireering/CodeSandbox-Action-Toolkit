declare function foo();
