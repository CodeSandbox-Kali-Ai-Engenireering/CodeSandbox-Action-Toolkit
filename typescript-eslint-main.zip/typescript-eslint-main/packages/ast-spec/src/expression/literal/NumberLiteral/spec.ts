import type { LiteralBase } from '../../../base/LiteralBase';

export interface NumberLiteral extends LiteralBase {
  value: number;
}
