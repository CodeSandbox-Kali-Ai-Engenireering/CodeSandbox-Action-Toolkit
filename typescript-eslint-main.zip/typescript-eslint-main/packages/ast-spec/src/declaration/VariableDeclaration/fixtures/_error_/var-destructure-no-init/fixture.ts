var { foo };
