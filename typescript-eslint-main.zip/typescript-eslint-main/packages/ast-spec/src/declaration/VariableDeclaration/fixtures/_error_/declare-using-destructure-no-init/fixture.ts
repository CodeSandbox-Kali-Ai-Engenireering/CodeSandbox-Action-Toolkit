declare using { foo };
