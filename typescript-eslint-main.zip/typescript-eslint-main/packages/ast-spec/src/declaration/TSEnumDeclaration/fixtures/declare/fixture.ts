declare enum Foo {}
