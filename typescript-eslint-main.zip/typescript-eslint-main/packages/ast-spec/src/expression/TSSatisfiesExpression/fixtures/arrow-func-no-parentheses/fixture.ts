() => 1 satisfies number;
