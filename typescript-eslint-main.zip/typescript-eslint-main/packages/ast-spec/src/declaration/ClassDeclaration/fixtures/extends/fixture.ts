class Foo extends Object {}
