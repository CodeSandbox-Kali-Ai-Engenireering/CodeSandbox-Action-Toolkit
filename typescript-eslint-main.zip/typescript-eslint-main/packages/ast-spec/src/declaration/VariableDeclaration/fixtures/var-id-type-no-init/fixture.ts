var foo: any;
