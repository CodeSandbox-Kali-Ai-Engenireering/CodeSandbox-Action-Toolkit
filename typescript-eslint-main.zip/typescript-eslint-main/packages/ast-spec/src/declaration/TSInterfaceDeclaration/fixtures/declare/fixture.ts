declare interface F {}
