class Foo {}
