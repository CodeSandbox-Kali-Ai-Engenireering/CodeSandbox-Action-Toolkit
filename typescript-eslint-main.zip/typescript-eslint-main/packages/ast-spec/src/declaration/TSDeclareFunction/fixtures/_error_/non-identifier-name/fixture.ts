declare function 1();
