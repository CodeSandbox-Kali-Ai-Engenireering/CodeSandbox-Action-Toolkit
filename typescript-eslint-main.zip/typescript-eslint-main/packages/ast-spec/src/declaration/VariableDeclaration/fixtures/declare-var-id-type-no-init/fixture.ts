declare var foo: any;
