@decorator
class Foo {}
