async function foo() {}
