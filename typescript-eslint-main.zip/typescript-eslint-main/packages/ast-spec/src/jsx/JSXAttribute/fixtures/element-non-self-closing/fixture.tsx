<App foo=<div>bar</div> />;
