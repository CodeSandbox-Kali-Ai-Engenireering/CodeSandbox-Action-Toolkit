function foo<1>() {}
