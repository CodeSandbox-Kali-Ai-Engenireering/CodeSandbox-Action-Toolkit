declare function foo(): void;
