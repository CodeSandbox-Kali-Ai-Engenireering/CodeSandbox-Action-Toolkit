declare namespace abd.def {}
