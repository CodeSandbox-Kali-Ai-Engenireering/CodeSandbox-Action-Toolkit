function foo(): void;
