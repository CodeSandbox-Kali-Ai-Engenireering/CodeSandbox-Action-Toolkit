declare function* foo();
