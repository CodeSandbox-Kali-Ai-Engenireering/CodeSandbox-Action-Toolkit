declare function foo<T>();
