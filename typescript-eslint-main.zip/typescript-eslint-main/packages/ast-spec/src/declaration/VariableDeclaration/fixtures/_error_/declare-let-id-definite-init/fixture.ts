declare let foo! = 1;
