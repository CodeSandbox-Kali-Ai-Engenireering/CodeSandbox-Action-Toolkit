import F = A.B.C;
