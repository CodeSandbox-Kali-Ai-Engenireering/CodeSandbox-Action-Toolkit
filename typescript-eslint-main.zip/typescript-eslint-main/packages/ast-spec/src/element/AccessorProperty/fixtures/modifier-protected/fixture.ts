class Foo {
  protected accessor foo = 2;
}
