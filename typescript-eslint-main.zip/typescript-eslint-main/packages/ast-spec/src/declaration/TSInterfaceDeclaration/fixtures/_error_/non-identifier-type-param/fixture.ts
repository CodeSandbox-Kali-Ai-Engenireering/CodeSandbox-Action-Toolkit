interface F<1> {}
