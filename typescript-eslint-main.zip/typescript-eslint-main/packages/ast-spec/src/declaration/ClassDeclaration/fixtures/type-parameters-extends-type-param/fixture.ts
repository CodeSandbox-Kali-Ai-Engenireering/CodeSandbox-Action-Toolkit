class Foo<T> extends Set<T> {}
