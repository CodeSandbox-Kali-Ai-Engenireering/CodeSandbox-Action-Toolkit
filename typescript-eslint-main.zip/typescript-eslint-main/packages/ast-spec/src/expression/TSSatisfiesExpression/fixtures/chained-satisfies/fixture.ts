foo satisfies bar satisfies baz;
