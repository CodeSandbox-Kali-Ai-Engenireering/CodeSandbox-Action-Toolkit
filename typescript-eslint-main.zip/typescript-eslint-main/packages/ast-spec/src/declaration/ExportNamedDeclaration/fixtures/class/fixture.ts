export class Foo {}
