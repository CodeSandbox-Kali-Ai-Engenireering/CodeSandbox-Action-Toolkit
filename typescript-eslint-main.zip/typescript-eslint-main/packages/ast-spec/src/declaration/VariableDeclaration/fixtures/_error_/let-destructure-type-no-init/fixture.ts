let { foo }: any;
