export namespace Foo {}
