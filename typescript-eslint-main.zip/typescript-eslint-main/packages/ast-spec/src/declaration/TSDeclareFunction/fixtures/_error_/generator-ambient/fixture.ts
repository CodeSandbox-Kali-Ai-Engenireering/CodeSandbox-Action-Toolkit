declare module "x" {
  function* foo(): any;
}
