export type * as x from 'a';
