declare var foo!: any;
