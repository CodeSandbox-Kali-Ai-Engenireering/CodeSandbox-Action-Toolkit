enum 1 {}
