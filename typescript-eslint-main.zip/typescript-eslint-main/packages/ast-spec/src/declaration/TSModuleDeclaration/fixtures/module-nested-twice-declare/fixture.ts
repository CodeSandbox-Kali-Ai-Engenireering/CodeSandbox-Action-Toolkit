declare module abc.def.ghi {}
