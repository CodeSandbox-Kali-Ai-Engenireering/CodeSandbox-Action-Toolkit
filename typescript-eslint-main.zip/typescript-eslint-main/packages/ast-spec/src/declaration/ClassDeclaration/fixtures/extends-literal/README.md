This is dumb code - but it's 100% syntactically valid and adheres to the ESTree spec.
