import * as a, { b } from 'a';
