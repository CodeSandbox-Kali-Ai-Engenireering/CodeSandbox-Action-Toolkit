declare let { foo }: any = 1;
