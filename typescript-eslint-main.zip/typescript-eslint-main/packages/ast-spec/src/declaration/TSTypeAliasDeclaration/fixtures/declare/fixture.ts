declare type T = 1;
