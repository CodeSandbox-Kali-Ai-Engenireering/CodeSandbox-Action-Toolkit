function foo(): void {}
