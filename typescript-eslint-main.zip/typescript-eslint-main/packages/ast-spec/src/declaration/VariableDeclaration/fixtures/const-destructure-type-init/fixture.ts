const { foo }: any = 1;
