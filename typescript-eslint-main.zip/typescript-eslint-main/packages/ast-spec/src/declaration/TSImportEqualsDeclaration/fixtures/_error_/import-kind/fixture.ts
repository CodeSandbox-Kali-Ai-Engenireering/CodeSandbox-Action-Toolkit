type T = 1;
import type F = T;
