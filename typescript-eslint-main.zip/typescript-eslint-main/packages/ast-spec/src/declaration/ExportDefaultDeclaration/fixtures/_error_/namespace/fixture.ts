export default namespace Foo {}
