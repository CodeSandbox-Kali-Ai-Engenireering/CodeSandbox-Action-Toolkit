interface F {
  prop;
}
