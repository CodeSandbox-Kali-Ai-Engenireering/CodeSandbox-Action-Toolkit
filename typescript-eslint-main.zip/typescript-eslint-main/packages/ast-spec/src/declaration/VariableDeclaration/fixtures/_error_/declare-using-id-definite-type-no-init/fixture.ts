declare using foo!: any;
