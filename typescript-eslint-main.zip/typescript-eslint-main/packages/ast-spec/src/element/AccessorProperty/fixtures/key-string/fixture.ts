class Foo {
  accessor 'quoted-prop' = 'value';
}
