class Foo {
  private accessor foo = 2;
}
