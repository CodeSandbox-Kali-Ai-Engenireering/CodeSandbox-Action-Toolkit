function foo<T, U, V>() {}
