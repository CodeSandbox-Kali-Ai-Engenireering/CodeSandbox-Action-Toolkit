declare const foo: any = 1;
