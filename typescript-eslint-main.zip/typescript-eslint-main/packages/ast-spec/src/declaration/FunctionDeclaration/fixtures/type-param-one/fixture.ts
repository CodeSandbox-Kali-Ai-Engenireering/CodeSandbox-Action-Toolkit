function foo<T>() {}
