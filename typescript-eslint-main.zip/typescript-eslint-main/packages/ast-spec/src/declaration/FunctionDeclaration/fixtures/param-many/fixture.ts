function foo(a, b, c) {}
