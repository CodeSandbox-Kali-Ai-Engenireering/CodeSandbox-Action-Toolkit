declare const foo!: any;
