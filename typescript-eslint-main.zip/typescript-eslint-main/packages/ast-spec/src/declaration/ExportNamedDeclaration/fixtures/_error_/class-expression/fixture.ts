export (class Foo {});
