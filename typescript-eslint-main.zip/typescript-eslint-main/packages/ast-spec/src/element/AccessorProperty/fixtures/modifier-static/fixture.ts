class Foo {
  static accessor foo = 2;
}
