@decoratorOne
@decoratorTwo
class Foo {}
