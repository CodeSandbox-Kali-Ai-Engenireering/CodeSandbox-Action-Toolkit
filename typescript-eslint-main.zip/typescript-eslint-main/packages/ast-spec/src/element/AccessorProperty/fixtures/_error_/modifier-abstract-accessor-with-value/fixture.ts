abstract class Foo {
  abstract accessor foo: number = 1;
}
