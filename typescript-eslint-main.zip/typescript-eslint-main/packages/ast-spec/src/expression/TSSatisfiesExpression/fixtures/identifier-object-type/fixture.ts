foo satisfies { prop: 'value' };
