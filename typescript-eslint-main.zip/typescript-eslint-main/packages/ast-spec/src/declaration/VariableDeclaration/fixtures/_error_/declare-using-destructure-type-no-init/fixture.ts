declare using { foo }: any;
