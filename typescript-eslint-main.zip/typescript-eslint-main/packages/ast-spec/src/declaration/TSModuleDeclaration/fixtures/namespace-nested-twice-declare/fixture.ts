declare namespace abc.def.ghi {}
