const { foo } = 1;
