foo satisfies [1, 2, 3];
