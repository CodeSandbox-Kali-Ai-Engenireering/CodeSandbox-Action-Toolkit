export default (class Foo {});
