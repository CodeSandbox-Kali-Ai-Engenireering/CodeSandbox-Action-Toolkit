export default type Foo = 1;
