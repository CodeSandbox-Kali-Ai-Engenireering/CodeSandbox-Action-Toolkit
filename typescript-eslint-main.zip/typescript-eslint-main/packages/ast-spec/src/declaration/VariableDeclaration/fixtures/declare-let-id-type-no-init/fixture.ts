declare let foo: any;
