class 'Foo' {}
