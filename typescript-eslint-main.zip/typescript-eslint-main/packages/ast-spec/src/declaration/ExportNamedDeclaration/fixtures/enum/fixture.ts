export enum Foo {}
