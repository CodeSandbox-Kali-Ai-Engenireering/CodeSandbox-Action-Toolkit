declare const foo: any;
