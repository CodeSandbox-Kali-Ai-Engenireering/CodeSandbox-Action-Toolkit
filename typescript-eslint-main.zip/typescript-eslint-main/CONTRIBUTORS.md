<!-- ------------------------------------------
 |      DO NOT MODIFY THIS FILE MANUALLY      |
 |                                            |
 | THIS FILE HAS BEEN AUTOMATICALLY GENERATED |
 |                                            |
 |     YOU CAN REGENERATE THIS FILE USING     |
 |         yarn generate-contributors         |
 ------------------------------------------- -->

# Contributors

Thanks goes to these wonderful people:

<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tr>
    <td align="center"><a href="https://github.com/bradzacher"><img src="https://avatars.githubusercontent.com/u/7462525?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Brad Zacher</b></sub></a></td>
    <td align="center"><a href="https://github.com/JamesHenry"><img src="https://avatars.githubusercontent.com/u/900523?v=4&size=100" width="100px;" alt=""/><br /><sub><b>James Henry</b></sub></a></td>
    <td align="center"><a href="https://github.com/armano2"><img src="https://avatars.githubusercontent.com/u/625469?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Armano</b></sub></a></td>
    <td align="center"><a href="https://github.com/JoshuaKGoldberg"><img src="https://avatars.githubusercontent.com/u/3335181?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Josh Goldberg ✨</b></sub></a></td>
    <td align="center"><a href="https://github.com/a-tarasyuk"><img src="https://avatars.githubusercontent.com/u/509265?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Oleksandr T.</b></sub></a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/Josh-Cena"><img src="https://avatars.githubusercontent.com/u/55398995?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Joshua Chen</b></sub></a></td>
    <td align="center"><a href="https://github.com/MichaelDeBoey"><img src="https://avatars.githubusercontent.com/u/6643991?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Michaël De Boey</b></sub></a></td>
    <td align="center"><a href="https://github.com/sosukesuzuki"><img src="https://avatars.githubusercontent.com/u/14838850?v=4&size=100" width="100px;" alt=""/><br /><sub><b>SUZUKI Sosuke</b></sub></a></td>
    <td align="center"><a href="https://github.com/soda0289"><img src="https://avatars.githubusercontent.com/u/2373964?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Reyad Attiyat</b></sub></a></td>
    <td align="center"><a href="https://github.com/G-Rath"><img src="https://avatars.githubusercontent.com/u/3151613?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Gareth Jones</b></sub></a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/yeonjuan"><img src="https://avatars.githubusercontent.com/u/41323220?v=4&size=100" width="100px;" alt=""/><br /><sub><b>YeonJuan</b></sub></a></td>
    <td align="center"><a href="https://github.com/weirdpattern"><img src="https://avatars.githubusercontent.com/u/19519411?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Patricio Trevino</b></sub></a></td>
    <td align="center"><a href="https://github.com/nzakas"><img src="https://avatars.githubusercontent.com/u/38546?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Nicholas C. Zakas</b></sub></a></td>
    <td align="center"><a href="https://github.com/j-f1"><img src="https://avatars.githubusercontent.com/u/25517624?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Jed Fox</b></sub></a></td>
    <td align="center"><a href="https://github.com/auvred"><img src="https://avatars.githubusercontent.com/u/61150013?v=4&size=100" width="100px;" alt=""/><br /><sub><b>auvred</b></sub></a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/rafaelss95"><img src="https://avatars.githubusercontent.com/u/11965907?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Rafael Santana</b></sub></a></td>
    <td align="center"><a href="https://github.com/uniqueiniquity"><img src="https://avatars.githubusercontent.com/u/9092011?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Ben Lichtman</b></sub></a></td>
    <td align="center"><a href="https://github.com/fisker"><img src="https://avatars.githubusercontent.com/u/172584?v=4&size=100" width="100px;" alt=""/><br /><sub><b>fisker Cheung</b></sub></a></td>
    <td align="center"><a href="https://github.com/phaux"><img src="https://avatars.githubusercontent.com/u/1270987?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Nikita</b></sub></a></td>
    <td align="center"><a href="https://github.com/lonyele"><img src="https://avatars.githubusercontent.com/u/15892571?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Taeheon Kim</b></sub></a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/Zamiell"><img src="https://avatars.githubusercontent.com/u/5511220?v=4&size=100" width="100px;" alt=""/><br /><sub><b>James</b></sub></a></td>
    <td align="center"><a href="https://github.com/RebeccaStevens"><img src="https://avatars.githubusercontent.com/u/7224206?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Rebecca Stevens</b></sub></a></td>
    <td align="center"><a href="https://github.com/scottohara"><img src="https://avatars.githubusercontent.com/u/289327?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Scott O'Hara</b></sub></a></td>
    <td align="center"><a href="https://github.com/bmish"><img src="https://avatars.githubusercontent.com/u/698306?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Bryan Mishkin</b></sub></a></td>
    <td align="center"><a href="https://github.com/Retsam"><img src="https://avatars.githubusercontent.com/u/2281166?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Retsam</b></sub></a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/kaicataldo"><img src="https://avatars.githubusercontent.com/u/7041728?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Kai Cataldo</b></sub></a></td>
    <td align="center"><a href="https://github.com/Pajn"><img src="https://avatars.githubusercontent.com/u/817422?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Rasmus Eneman</b></sub></a></td>
    <td align="center"><a href="https://github.com/mysticatea"><img src="https://avatars.githubusercontent.com/u/1937871?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Toru Nagashima</b></sub></a></td>
    <td align="center"><a href="https://github.com/ota-meshi"><img src="https://avatars.githubusercontent.com/u/16508807?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Yosuke Ota</b></sub></a></td>
    <td align="center"><a href="https://github.com/omril1"><img src="https://avatars.githubusercontent.com/u/18642549?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Omri Luzon</b></sub></a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/JounQin"><img src="https://avatars.githubusercontent.com/u/8336744?v=4&size=100" width="100px;" alt=""/><br /><sub><b>JounQin</b></sub></a></td>
    <td align="center"><a href="https://github.com/azz"><img src="https://avatars.githubusercontent.com/u/1297597?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Lucas Azzola</b></sub></a></td>
    <td align="center"><a href="https://github.com/SimenB"><img src="https://avatars.githubusercontent.com/u/1404810?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Simen Bekkhus</b></sub></a></td>
    <td align="center"><a href="https://github.com/dannyfritz"><img src="https://avatars.githubusercontent.com/u/315788?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Danny Fritz</b></sub></a></td>
    <td align="center"><a href="https://github.com/ikatyang"><img src="https://avatars.githubusercontent.com/u/8341033?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Ika</b></sub></a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/cherryblossom000"><img src="https://avatars.githubusercontent.com/u/31467609?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Lauren Yim</b></sub></a></td>
    <td align="center"><a href="https://github.com/macklinu"><img src="https://avatars.githubusercontent.com/u/2344137?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Mackie Underdown</b></sub></a></td>
    <td align="center"><a href="https://github.com/sviat9440"><img src="https://avatars.githubusercontent.com/u/13107421?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Sviatoslav Zaytsev</b></sub></a></td>
    <td align="center"><a href="https://github.com/islandryu"><img src="https://avatars.githubusercontent.com/u/65934663?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Shima Ryuhei</b></sub></a></td>
    <td align="center"><a href="https://github.com/lukyth"><img src="https://avatars.githubusercontent.com/u/7040242?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Kanitkorn Sujautra</b></sub></a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/NotWoods"><img src="https://avatars.githubusercontent.com/u/1782266?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Tiger Oakes</b></sub></a></td>
    <td align="center"><a href="https://github.com/juank1809"><img src="https://avatars.githubusercontent.com/u/82288753?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Juan García</b></sub></a></td>
    <td align="center"><a href="https://github.com/Zzzen"><img src="https://avatars.githubusercontent.com/u/6630042?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Zzzen</b></sub></a></td>
    <td align="center"><a href="https://github.com/cparros"><img src="https://avatars.githubusercontent.com/u/65684072?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Cparros</b></sub></a></td>
    <td align="center"><a href="https://github.com/ddubrava"><img src="https://avatars.githubusercontent.com/u/22116465?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Daniil Dubrava</b></sub></a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/octogonz"><img src="https://avatars.githubusercontent.com/u/4673363?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Pete Gonzalez</b></sub></a></td>
    <td align="center"><a href="https://github.com/ldrick"><img src="https://avatars.githubusercontent.com/u/3674067?v=4&size=100" width="100px;" alt=""/><br /><sub><b>ldrick</b></sub></a></td>
    <td align="center"><a href="https://github.com/StyleShit"><img src="https://avatars.githubusercontent.com/u/32631382?v=4&size=100" width="100px;" alt=""/><br /><sub><b>StyleShit</b></sub></a></td>
    <td align="center"><a href="https://github.com/susisu"><img src="https://avatars.githubusercontent.com/u/2443491?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Susisu</b></sub></a></td>
    <td align="center"><a href="https://github.com/kmin-jeong"><img src="https://avatars.githubusercontent.com/u/53456037?v=4&size=100" width="100px;" alt=""/><br /><sub><b>kmin-jeong</b></sub></a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/gavinbarron"><img src="https://avatars.githubusercontent.com/u/7122716?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Gavin Barron</b></sub></a></td>
    <td align="center"><a href="https://github.com/Validark"><img src="https://avatars.githubusercontent.com/u/15217173?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Niles Salter</b></sub></a></td>
    <td align="center"><a href="https://github.com/pablobirukov"><img src="https://avatars.githubusercontent.com/u/1861546?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Pavel Birukov </b></sub></a></td>
    <td align="center"><a href="https://github.com/mightyiam"><img src="https://avatars.githubusercontent.com/u/635591?v=4&size=100" width="100px;" alt=""/><br /><sub><b>Shahar "Dawn" Or</b></sub></a></td>
    <td align="center"><a href="https://github.com/kirkwaiblinger"><img src="https://avatars.githubusercontent.com/u/53019676?v=4&size=100" width="100px;" alt=""/><br /><sub><b>kirkwaiblinger</b></sub></a></td>
  </tr>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<sup>This list is auto-generated using `yarn generate-contributors`. It shows the top 100 contributors with > 3 contributions.</sup>
