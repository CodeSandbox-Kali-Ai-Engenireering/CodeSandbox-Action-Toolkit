let foo: any = 1;
