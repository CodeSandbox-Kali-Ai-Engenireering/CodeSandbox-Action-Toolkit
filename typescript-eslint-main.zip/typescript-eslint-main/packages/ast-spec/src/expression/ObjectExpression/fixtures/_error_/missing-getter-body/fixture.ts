({get foo();})
