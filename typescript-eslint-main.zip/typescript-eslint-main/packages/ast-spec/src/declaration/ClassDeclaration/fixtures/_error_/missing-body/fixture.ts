class Foo;
