class Foo {
  prop;
}
