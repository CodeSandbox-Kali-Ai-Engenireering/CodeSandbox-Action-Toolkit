enum Foo {
  A,
}
