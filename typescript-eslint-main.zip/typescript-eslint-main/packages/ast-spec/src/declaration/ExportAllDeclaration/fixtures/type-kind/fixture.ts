export type * from 'a';
