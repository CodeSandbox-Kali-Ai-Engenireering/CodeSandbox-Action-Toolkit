import type { LiteralBase } from '../../../base/LiteralBase';

export interface StringLiteral extends LiteralBase {
  value: string;
}
