const foo: any;
