using { foo } = 1;
