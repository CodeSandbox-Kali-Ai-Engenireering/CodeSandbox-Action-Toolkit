declare using foo!;
