import { b }, * as a from 'a';
