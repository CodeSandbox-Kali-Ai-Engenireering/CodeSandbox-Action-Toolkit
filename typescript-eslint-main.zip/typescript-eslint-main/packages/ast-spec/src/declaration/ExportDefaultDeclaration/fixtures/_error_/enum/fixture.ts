export default enum Foo {}
