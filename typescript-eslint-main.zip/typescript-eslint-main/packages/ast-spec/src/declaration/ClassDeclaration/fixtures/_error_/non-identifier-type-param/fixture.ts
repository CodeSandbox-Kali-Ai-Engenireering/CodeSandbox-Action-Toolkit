class C<1> {}
