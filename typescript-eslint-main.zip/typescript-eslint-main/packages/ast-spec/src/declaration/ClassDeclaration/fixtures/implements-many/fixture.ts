class Foo implements Object, Function, RegExp {}
