@decl type Test = {};
