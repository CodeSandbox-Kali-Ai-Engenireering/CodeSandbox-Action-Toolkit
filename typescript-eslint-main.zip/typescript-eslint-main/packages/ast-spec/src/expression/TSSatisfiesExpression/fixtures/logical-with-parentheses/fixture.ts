(foo === 1) satisfies boolean;
