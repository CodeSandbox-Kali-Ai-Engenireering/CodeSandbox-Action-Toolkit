class Foo {
  public public bar() {};
}
