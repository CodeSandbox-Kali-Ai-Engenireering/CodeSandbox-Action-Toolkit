type T<> = 1;
