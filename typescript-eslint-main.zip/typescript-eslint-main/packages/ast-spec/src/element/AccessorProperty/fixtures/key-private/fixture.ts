class Foo {
  accessor #foo = 2;
}
