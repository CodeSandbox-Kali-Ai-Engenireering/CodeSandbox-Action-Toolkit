declare let { foo }: any;
