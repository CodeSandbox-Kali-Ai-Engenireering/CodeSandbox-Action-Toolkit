declare const foo! = 1;
