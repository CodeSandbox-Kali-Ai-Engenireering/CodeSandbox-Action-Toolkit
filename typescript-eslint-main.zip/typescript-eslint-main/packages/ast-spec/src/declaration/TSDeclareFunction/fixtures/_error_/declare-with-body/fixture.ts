declare function foo(): void {};
