@decl interface Test {}
