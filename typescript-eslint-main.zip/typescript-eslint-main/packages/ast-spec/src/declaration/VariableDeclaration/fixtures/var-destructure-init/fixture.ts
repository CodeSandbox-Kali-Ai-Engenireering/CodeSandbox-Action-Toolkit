var { foo } = 1;
