declare const foo;
