export type Accessibility = 'private' | 'protected' | 'public';
