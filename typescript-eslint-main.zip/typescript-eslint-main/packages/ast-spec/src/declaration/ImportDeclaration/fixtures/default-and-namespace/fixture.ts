import a, * as b from 'mod';
