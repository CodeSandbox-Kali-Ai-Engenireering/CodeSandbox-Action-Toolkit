class Foo<T> {}
