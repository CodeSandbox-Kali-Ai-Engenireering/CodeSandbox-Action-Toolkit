declare function foo<T, U, V>();
