export declare namespace abc.def.ghi {}
