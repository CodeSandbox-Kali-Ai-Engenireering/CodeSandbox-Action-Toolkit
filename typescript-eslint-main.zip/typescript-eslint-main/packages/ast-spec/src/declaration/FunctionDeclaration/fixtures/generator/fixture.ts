function* foo() {}
