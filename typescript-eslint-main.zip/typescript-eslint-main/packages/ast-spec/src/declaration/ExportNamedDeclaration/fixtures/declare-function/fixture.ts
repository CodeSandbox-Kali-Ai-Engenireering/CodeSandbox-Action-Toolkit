export declare function foo(): void;
