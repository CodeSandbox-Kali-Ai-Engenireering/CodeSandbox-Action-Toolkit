class Foo extends 'Thing' {}
