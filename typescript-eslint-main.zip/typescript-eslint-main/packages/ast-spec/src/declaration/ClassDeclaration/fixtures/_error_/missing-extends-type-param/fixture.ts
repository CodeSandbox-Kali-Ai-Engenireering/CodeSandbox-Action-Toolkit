class C extends D<> {}
