declare var { foo };
