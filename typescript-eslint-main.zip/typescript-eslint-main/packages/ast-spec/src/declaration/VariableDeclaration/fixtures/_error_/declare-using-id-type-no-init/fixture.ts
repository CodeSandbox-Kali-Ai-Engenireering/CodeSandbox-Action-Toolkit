declare using foo: any;
