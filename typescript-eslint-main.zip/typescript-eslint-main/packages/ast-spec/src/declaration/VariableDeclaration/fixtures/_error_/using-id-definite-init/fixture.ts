using foo! = 1;
