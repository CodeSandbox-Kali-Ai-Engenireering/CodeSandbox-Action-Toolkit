# You must use one of our issue templates to file an issue.

# [https://github.com/typescript-eslint/typescript-eslint/issues/new/choose](https://github.com/typescript-eslint/typescript-eslint/issues/new/choose)

# Issues filed without using a template will be closed without action, and we will ask you to use a template.

## [https://github.com/typescript-eslint/typescript-eslint/issues/new/choose](https://github.com/typescript-eslint/typescript-eslint/issues/new/choose)
