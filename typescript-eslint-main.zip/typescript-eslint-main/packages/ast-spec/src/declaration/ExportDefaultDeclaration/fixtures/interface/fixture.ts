export default interface Foo {}
