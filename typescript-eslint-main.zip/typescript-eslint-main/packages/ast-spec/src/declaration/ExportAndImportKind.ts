type ExportAndImportKind = 'type' | 'value';

export type ExportKind = ExportAndImportKind;
export type ImportKind = ExportAndImportKind;
