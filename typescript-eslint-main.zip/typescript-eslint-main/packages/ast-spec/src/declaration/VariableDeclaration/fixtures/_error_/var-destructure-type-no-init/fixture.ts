var { foo }: any;
