class C<> {}
