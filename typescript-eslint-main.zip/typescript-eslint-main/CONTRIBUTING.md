# Contributing

See **https://typescript-eslint.io/contributing** for our contributing guidelines.
Thanks! 💖
