interface F extends {}
