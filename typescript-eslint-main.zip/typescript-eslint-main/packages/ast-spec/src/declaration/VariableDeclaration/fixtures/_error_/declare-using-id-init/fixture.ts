declare using foo = 1;
