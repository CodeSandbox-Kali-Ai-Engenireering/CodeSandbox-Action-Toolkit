let { foo };
