declare using foo;
