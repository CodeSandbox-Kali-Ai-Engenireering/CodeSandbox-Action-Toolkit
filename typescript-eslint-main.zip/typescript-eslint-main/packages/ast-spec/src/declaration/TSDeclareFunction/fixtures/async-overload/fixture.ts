async function foo(): any;
async function foo(): any {}
