import * as x from module;
