({set foo(value);})
