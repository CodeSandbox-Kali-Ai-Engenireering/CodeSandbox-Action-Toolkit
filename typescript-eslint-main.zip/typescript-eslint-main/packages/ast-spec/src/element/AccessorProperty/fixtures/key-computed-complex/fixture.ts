class Foo {
  accessor [1 + 1] = 2;
}
