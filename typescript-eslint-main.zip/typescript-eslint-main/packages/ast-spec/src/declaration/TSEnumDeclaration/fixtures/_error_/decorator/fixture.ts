@decl enum Test {}
