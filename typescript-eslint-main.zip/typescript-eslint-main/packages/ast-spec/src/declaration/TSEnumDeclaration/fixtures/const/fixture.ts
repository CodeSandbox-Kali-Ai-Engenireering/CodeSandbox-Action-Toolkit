const enum Foo {}
