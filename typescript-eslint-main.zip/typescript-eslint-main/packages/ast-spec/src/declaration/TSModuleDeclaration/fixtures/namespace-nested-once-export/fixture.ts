export namespace abd.def {}
