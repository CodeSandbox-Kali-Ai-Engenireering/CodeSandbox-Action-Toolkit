class Foo {
  accessor prop;
}
