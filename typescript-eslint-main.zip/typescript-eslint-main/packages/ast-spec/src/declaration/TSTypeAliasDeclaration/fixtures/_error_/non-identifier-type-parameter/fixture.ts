type T<1> = 2;
