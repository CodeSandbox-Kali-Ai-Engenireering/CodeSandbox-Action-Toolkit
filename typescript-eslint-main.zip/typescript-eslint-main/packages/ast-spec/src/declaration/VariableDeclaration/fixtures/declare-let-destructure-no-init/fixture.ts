declare let { foo };
